"""Khởi chạy bot bằng polling trên máy cục bộ."""

from app.bot import main


if __name__ == "__main__":
    main()
